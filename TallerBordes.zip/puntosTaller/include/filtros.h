#ifndef FILTROS_H
#define FILTROS_H

#include <opencv2/opencv.hpp>

cv::Mat log(const cv::Mat& img);
cv::Mat zeroCrossing(const cv::Mat& img);
cv::Mat sobel(const cv::Mat& img);
cv::Mat scharr(const cv::Mat& img);
cv::Mat laplaciano(const cv::Mat& img);
cv::Mat sobelMagnitude(const cv::Mat& img);

cv::Mat canny(const cv::Mat& img);

#endif
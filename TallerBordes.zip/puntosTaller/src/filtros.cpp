#include "../include/filtros.h"
#include <cmath>
#include <algorithm>
#include <vector>


// ============================
// CONVOLUCION GENERAL
// ============================

static cv::Mat convolucion(const cv::Mat& img, const std::vector<std::vector<int>>& kernel)
{
    int k = kernel.size()/2;

    cv::Mat resultado = cv::Mat::zeros(img.size(), CV_16S);

    for(int i=k;i<img.rows-k;i++)
    {
        for(int j=k;j<img.cols-k;j++)
        {
            int suma=0;

            for(int ki=-k;ki<=k;ki++)
            {
                for(int kj=-k;kj<=k;kj++)
                {
                    int pixel = img.at<uchar>(i+ki,j+kj);
                    int peso = kernel[ki+k][kj+k];

                    suma += pixel * peso;
                }
            }

            resultado.at<short>(i,j)=suma;
        }
    }

    return resultado;
}

static cv::Mat normalizar(const cv::Mat& img)
{
    cv::Mat out(img.size(),CV_8U);

    for(int i=0;i<img.rows;i++)
    {
        for(int j=0;j<img.cols;j++)
        {
            int v = std::abs(img.at<short>(i,j));
            v = std::min(255,v);

            out.at<uchar>(i,j)=v;
        }
    }

    return out;
}


// ============================
// 1. LoG
// ============================

static cv::Mat gaussian(const cv::Mat& img)
{
    std::vector<std::vector<int>> kernel =
    {
        {1,2,1},
        {2,4,2},
        {1,2,1}
    };

    cv::Mat conv = convolucion(img,kernel);

    cv::Mat blur(img.size(),CV_8U);

    for(int i=0;i<img.rows;i++)
    {
        for(int j=0;j<img.cols;j++)
        {
            blur.at<uchar>(i,j)=conv.at<short>(i,j)/16;
        }
    }

    return blur;
}

cv::Mat log(const cv::Mat& img)
{
    cv::Mat blur = gaussian(img);

    std::vector<std::vector<int>> kernel =
    {
        {0,1,0},
        {1,-4,1},
        {0,1,0}
    };

    return convolucion(blur,kernel);
}


// ============================
// 2. Zero Crossing
// ============================

cv::Mat zeroCrossing(const cv::Mat& img)
{
    cv::Mat edges = cv::Mat::zeros(img.size(),CV_8U);

    for(int i=1;i<img.rows-1;i++)
    {
        for(int j=1;j<img.cols-1;j++)
        {
            int p = img.at<short>(i,j);

            bool edge=false;

            for(int ki=-1;ki<=1;ki++)
            {
                for(int kj=-1;kj<=1;kj++)
                {
                    int n = img.at<short>(i+ki,j+kj);

                    if(p*n < 0)
                        edge=true;
                }
            }

            if(edge)
                edges.at<uchar>(i,j)=255;
        }
    }

    return edges;
}


// ============================
// 3. Sobel
// ============================

cv::Mat sobel(const cv::Mat& img)
{
    std::vector<std::vector<int>> kernel =
    {
        {-1,0,1},
        {-2,0,2},
        {-1,0,1}
    };

    return normalizar(convolucion(img,kernel));
}


// ============================
// 4. Scharr
// ============================

cv::Mat scharr(const cv::Mat& img)
{
    std::vector<std::vector<int>> kernel =
    {
        {-3,0,3},
        {-10,0,10},
        {-3,0,3}
    };

    return normalizar(convolucion(img,kernel));
}


// ============================
// 5. Laplaciano
// ============================

cv::Mat laplaciano(const cv::Mat& img)
{
    std::vector<std::vector<int>> kernel =
    {
        {0,1,0},
        {1,-4,1},
        {0,1,0}
    };

    return normalizar(convolucion(img,kernel));
}


// ============================
// 6. Sobel Magnitude
// ============================

cv::Mat sobelMagnitude(const cv::Mat& img)
{
    std::vector<std::vector<int>> sx =
    {
        {-1,0,1},
        {-2,0,2},
        {-1,0,1}
    };

    std::vector<std::vector<int>> sy =
    {
        {-1,-2,-1},
        {0,0,0},
        {1,2,1}
    };

    cv::Mat gx = convolucion(img,sx);
    cv::Mat gy = convolucion(img,sy);

    cv::Mat mag(img.size(),CV_8U);

    for(int i=0;i<img.rows;i++)
    {
        for(int j=0;j<img.cols;j++)
        {
            int v = std::sqrt(
                gx.at<short>(i,j)*gx.at<short>(i,j) +
                gy.at<short>(i,j)*gy.at<short>(i,j)
            );

            v = std::min(255,v);

            mag.at<uchar>(i,j)=v;
        }
    }

    return mag;
}


// ============================
// 7. Canny
// ============================

cv::Mat canny(const cv::Mat& img)
{
    cv::Mat blur = gaussian(img);

    std::vector<std::vector<int>> sx =
    {
        {-1,0,1},
        {-2,0,2},
        {-1,0,1}
    };

    std::vector<std::vector<int>> sy =
    {
        {-1,-2,-1},
        {0,0,0},
        {1,2,1}
    };

    cv::Mat gx = convolucion(blur,sx);
    cv::Mat gy = convolucion(blur,sy);

    cv::Mat edges(img.size(),CV_8U);

    int low=50;
    int high=100;

    for(int i=0;i<img.rows;i++)
    {
        for(int j=0;j<img.cols;j++)
        {
            int g = std::sqrt(
                gx.at<short>(i,j)*gx.at<short>(i,j) +
                gy.at<short>(i,j)*gy.at<short>(i,j)
            );

            if(g>high)
                edges.at<uchar>(i,j)=255;
            else if(g>low)
                edges.at<uchar>(i,j)=100;
            else
                edges.at<uchar>(i,j)=0;
        }
    }

    return edges;
}
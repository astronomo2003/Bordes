#include <opencv2/opencv.hpp>
#include <iostream>
#include "../include/filtros.h"

cv::Mat preparar(const cv::Mat& img, std::string nombre)
{
    cv::Mat temp, color;

    if(img.depth() != CV_8U)
        cv::convertScaleAbs(img, temp);
    else
        temp = img;

    if(temp.channels() == 1)
        cv::cvtColor(temp, color, cv::COLOR_GRAY2BGR);
    else
        color = temp;

    cv::resize(color, color, cv::Size(320,240));

    cv::putText(color, nombre,
                cv::Point(10,25),
                cv::FONT_HERSHEY_SIMPLEX,
                0.7,
                cv::Scalar(0,255,0),
                2);

    return color;
}

int main()
{
    cv::VideoCapture cap(0);

    if(!cap.isOpened())
    {
        std::cout<<"No se pudo abrir la camara\n";
        return -1;
    }

    cv::Mat frame, gray;

    while(true)
    {
        cap >> frame;

        if(frame.empty())
            break;

        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);

        cv::Mat logImg = log(gray);
        cv::Mat zero = zeroCrossing(logImg);
        cv::Mat sobelImg = sobel(gray);
        cv::Mat scharrImg = scharr(gray);
        cv::Mat lap = laplaciano(gray);
        cv::Mat sobelMag = sobelMagnitude(gray);
        cv::Mat cannyImg = canny(gray);

        cv::Mat original_p = preparar(frame, "Original");
        cv::Mat log_p = preparar(logImg, "LoG");
        cv::Mat zero_p = preparar(zero, "Zero Crossing");
        cv::Mat sobel_p = preparar(sobelImg, "Sobel");
        cv::Mat scharr_p = preparar(scharrImg, "Scharr");
        cv::Mat lap_p = preparar(lap, "Laplaciano");
        cv::Mat sobelMag_p = preparar(sobelMag, "Sobel Magnitude");
        cv::Mat canny_p = preparar(cannyImg, "Canny");

        cv::Mat fila1, fila2, mosaico;

        cv::hconcat(std::vector<cv::Mat>{original_p, log_p, zero_p, sobel_p}, fila1);
        cv::hconcat(std::vector<cv::Mat>{scharr_p, lap_p, sobelMag_p, canny_p}, fila2);

        cv::vconcat(fila1, fila2, mosaico);

        cv::imshow("Filtros en tiempo real", mosaico);

        char key = cv::waitKey(19);

        if(key=='q')
            break;
    }

    cap.release();
    cv::destroyAllWindows();

    return 0;
}